#include "vex.h"

void setDrive() {
  indexer.set(true);
  intake.setVelocity(100, percent);
  intake.spinFor(forward,360,degrees,true);
}
bool fromAutonLine;
int discsinMag;
void shoot(bool fromAutonLine, int discsinMag) {
   if (fromAutonLine) {
    indexer.set(false);
    for (int DM = 0; DM<discsinMag; DM++ ) 
    {
    wait(1,sec);
    intake.spin(reverse,10,volt);
    wait(0.1,sec);
    intake.stop();
    }
  }
    indexer.set(false);
    intake.spin(reverse,12,volt);
    
  
  }
float fwRPM;
void flyW(float fwRPM) {
  flywheel.spin(fwd, fwRPM , rpm);
}


void default_constants(){
  chassis.set_drive_constants(10, 1.5, 0, 10, 0);
  chassis.set_heading_constants(6, .4, 0, 1, 0);
  chassis.set_turn_constants(12, .4, .03, 3, 15);
  chassis.set_swing_constants(12, .3, .001, 2, 15);
  chassis.set_drive_exit_conditions(1.5, 300, 5000);
  chassis.set_turn_exit_conditions(1, 300, 3000);
  chassis.set_swing_exit_conditions(1, 300, 3000);
}

void drive_test() {
  // right side
  setDrive();
  intake.spin(reverse,11,volt);
  chassis.drive_distance(36,0,9,3);
  wait(0.3,sec);
  intake.spin(fwd,11,volt);
  flywheel.spin(fwd,3600,rpm);
  chassis.drive_distance(18,0,9,3);
  chassis.turn_to_angle(38,4);
  wait(0.1,sec);
  shoot(true,3);
  wait(2,sec);
  indexer.set(true);
  intake.spin(reverse,11,volt);
  chassis.drive_distance(12,38,4,4);
  flywheel.stop(coast);
  shoot(true,1);
  wait(0.3,sec);
  chassis.drive_distance(-15,38,6,4);
  chassis.turn_to_angle(-45, 4);
  chassis.drive_distance(-48,-45,9,3);
  intake.stop();
  chassis.turn_to_angle(0,3);
  intake.spinFor(fwd,-3600,degrees,false);
  chassis.drive_distance(-18,0,3,4);






}

void turn_test(){
  //left side solo wp
  setDrive();
  intake.spin(reverse,9,volt);
  chassis.drive_distance(-18,0,6,3);
  chassis.drive_distance(32,0,9,3);
  intake.spin(fwd,9,volt);
  chassis.turn_to_angle(45, 6);
  flyW(3600);
  chassis.drive_distance(98,45,9,4);
  chassis.turn_to_angle(-45,6);
  shoot(true,2);
  wait(2,sec);
  chassis.turn_to_angle(-135,6);
  flywheel.stop(coast);
  chassis.drive_distance(-108,-134,9.6,4);
  chassis.turn_to_angle(-90,6);
  intake.spin(reverse,5,volt);
  chassis.drive_distance(-28,-90,6,3);
  wait(0.2,sec);

  chassis.drive_distance(24,-90,9,3);


  
}

void swing_test(){
  setDrive();
  intake.spin(reverse,9,volt);
  chassis.drive_distance(-18,0,6,3);
  chassis.drive_distance(32,0,9,3);
  intake.spin(fwd,9,volt);
  chassis.turn_to_angle(45, 6);
  flyW(3600);
  chassis.drive_distance(98,45,9,4);
  chassis.turn_to_angle(-45,6);
  shoot(true,2);
  wait(3,sec);
  flywheel.stop();
}

void full_test(){
  //skills
  setDrive();
  intake.spin(reverse,9,volt);
  chassis.drive_distance(-12,0,6,3);
  chassis.drive_distance(12,0,9,3);
  chassis.turn_to_angle(-45, 6);
  intake.spin(reverse,11,volt);
  chassis.drive_distance(26,-45,9,4);
  wait(0.3,sec);
  intake.spin(fwd,11,volt);
  wait(0.3,sec);
  intake.stop();
  chassis.turn_to_angle(0,6);
  chassis.drive_distance(20,0,9,4);
  chassis.turn_to_angle(90,6);
  intake.spin(reverse,9,volt);
  chassis.drive_distance(-36,90,6,3);
  chassis.drive_distance(8,90,9,3);
  chassis.turn_to_angle(0,6);
  flyW(3450);
  angler.set(true);
  chassis.drive_distance(100,0,9,6);
  chassis.turn_to_angle(10,3);
  wait(2,sec);
  shoot(false,3);
  wait(1,sec);
  flywheel.stop();
  chassis.turn_to_angle(0,3);
  chassis.drive_distance(-100,0,9,6);
  chassis.turn_to_angle(45,6);
  intake.spin(reverse,11,volt);
  chassis.drive_distance(50,45,5,6);
  intake.spin(fwd,11,volt);
  chassis.drive_distance(114,45,5,4);

  






  
}

void odom_test(){
  chassis.set_coordinates(0, 0, 0);
  while(1){
    Brain.Screen.clearScreen();
    Brain.Screen.printAt(0,50, "X: %f", chassis.get_X_position());
    Brain.Screen.printAt(0,70, "Y: %f", chassis.get_Y_position());
    Brain.Screen.printAt(0,90, "Heading: %f", chassis.get_absolute_heading());
    Brain.Screen.printAt(0,110, "ForwardTracker: %f", chassis.get_ForwardTracker_position());
    Brain.Screen.printAt(0,130, "SidewaysTracker: %f", chassis.get_SidewaysTracker_position());
    task::sleep(20);
  }
}

void tank_odom_test(){
  chassis.set_coordinates(0, 0, 0);
  chassis.drive_to_point(6, 18);
  chassis.turn_to_point(12,0, 180);
  chassis.drive_to_point(12, 0);
  chassis.turn_to_angle(100);
  chassis.drive_to_point(0, 0);
}

void holonomic_odom_test(){
  chassis.set_coordinates(0, 0, 0);
  chassis.holonomic_drive_to_point(0, 18, 90);
  chassis.holonomic_drive_to_point(18, 0, 180);
  chassis.holonomic_drive_to_point(0, 18, 270);
  chassis.holonomic_drive_to_point(0, 0, 0);
}